package agentes;

public class Agentes {
    public static void main(String[] args) {
        new Scene().setVisible(true);
    }
}
